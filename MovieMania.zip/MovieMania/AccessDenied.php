<?php
	echo "<script>
			alert('Sorry. You are not allowed to access this page.');
			history.go(-1);
	</script>";
?>